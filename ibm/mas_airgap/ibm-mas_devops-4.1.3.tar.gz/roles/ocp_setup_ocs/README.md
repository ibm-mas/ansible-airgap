ocp_setup_ocs
=============

This role provides support to install Openshift Container Storage. This role is not used by default when setting up IBM Cloud ROKS clusters because they are automatically provisioned with their own storage plugin already.


Role Variables
--------------

TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO: Add example
```

License
-------

EPL-2.0
