ocp_setup_mas_deps
==================

This role provides support to install operators that are required by MAS to work. The role will deploy Service Binding Operator in all namespaces and Cert Manager in the cert-manager namespace.  The role declares a dependency on `ocp_verify` to ensure that the RedHat Operator Catalog is installed and ready before we try to install the Service Binding Operator from that catalog.


Role Variables
--------------

TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO: Add example
```

License
-------

EPL-2.0
