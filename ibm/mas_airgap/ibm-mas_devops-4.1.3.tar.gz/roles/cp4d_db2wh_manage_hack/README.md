cp4d_db2wh_manage_hack
======================

TODO: Summarize role

Role Variables
--------------

TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO: Add example
```

License
-------

EPL-2.0
