bas_install
===========

TODO: Add intro

Role Variables
--------------

TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO
```

License
-------

EPL-2.0
