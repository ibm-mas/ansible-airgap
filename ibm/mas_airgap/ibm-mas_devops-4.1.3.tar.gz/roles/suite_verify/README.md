suite_verify
============

TODO: Summarize role

Role Variables
--------------

TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO: Add example
```

License
-------

EPL-2.0
